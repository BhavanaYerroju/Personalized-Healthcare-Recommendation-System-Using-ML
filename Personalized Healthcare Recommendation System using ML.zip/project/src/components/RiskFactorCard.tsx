import React, { useState } from 'react';
import { RiskFactor } from '../types/health';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface RiskFactorCardProps {
  riskFactor: RiskFactor;
}

const RiskFactorCard: React.FC<RiskFactorCardProps> = ({ riskFactor }) => {
  const [expanded, setExpanded] = useState(false);

  const toggleExpanded = () => {
    setExpanded(!expanded);
  };

  const getRiskLevelClasses = (riskLevel: 'low' | 'moderate' | 'high') => {
    switch (riskLevel) {
      case 'low':
        return 'bg-success-50 text-success-700';
      case 'moderate':
        return 'bg-warning-50 text-warning-700';
      case 'high':
        return 'bg-error-50 text-error-700';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-all">
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-800">{riskFactor.condition}</h3>
            <div className="flex items-center mt-1">
              <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getRiskLevelClasses(riskFactor.riskLevel)}`}>
                {riskFactor.riskLevel.charAt(0).toUpperCase() + riskFactor.riskLevel.slice(1)} Risk
              </span>
              <span className="ml-2 text-xs text-gray-500">
                {Math.round(riskFactor.probability * 100)}% probability
              </span>
            </div>
          </div>
          <button 
            onClick={toggleExpanded}
            className="p-1 rounded-full hover:bg-gray-100 transition-colors"
            aria-label={expanded ? "Collapse" : "Expand"}
          >
            {expanded ? (
              <ChevronUp className="h-5 w-5 text-gray-500" />
            ) : (
              <ChevronDown className="h-5 w-5 text-gray-500" />
            )}
          </button>
        </div>
        
        <p className="mt-3 text-gray-600">
          {riskFactor.description}
        </p>
        
        {expanded && (
          <div className="mt-4 animate-fade-in">
            <div className="mt-3">
              <h4 className="font-medium text-gray-800 mb-2">Contributing Factors:</h4>
              <ul className="list-disc pl-5 space-y-1">
                {riskFactor.contributingFactors.map((factor, index) => (
                  <li key={index} className="text-gray-600">{factor}</li>
                ))}
              </ul>
            </div>
            
            <div className="mt-4">
              <h4 className="font-medium text-gray-800 mb-2">Preventive Actions:</h4>
              <ul className="list-disc pl-5 space-y-1">
                {riskFactor.preventiveActions.map((action, index) => (
                  <li key={index} className="text-gray-600">{action}</li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RiskFactorCard;