import React from 'react';
import { HealthMetric } from '../types/health';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface HealthMetricCardProps {
  metric: HealthMetric;
}

const HealthMetricCard: React.FC<HealthMetricCardProps> = ({ metric }) => {
  // Calculate trend
  const currentValue = metric.value;
  const previousValue = metric.history.length > 0 ? metric.history[0].value : currentValue;
  const trend = currentValue === previousValue ? 'stable' : currentValue > previousValue ? 'up' : 'down';
  
  // Determine if trend is positive or negative based on status
  const isTrendPositive = 
    (metric.status === 'normal' && trend === 'stable') || 
    (metric.status === 'warning' && trend === 'down') || 
    (metric.status === 'critical' && trend === 'down');

  // Chart data
  const chartData = {
    labels: [...metric.history.map(h => new Date(h.date).toLocaleDateString()), 'Current'],
    datasets: [
      {
        label: metric.name,
        data: [...metric.history.map(h => h.value), metric.value],
        borderColor: getStatusColor(metric.status, 500),
        backgroundColor: getStatusColor(metric.status, 100),
        fill: false,
        tension: 0.4,
      },
      {
        label: 'Min',
        data: Array(metric.history.length + 1).fill(metric.normalRange.min),
        borderColor: 'rgba(75, 192, 192, 0.5)',
        borderDash: [5, 5],
        fill: false,
        pointRadius: 0,
      },
      {
        label: 'Max',
        data: Array(metric.history.length + 1).fill(metric.normalRange.max),
        borderColor: 'rgba(75, 192, 192, 0.5)',
        borderDash: [5, 5],
        fill: false,
        pointRadius: 0,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: false,
      },
    },
    plugins: {
      legend: {
        display: false,
      },
    },
    elements: {
      point: {
        radius: 3,
      },
    },
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">{metric.name}</h3>
          <p className="text-sm text-gray-500">Last updated: {new Date(metric.date).toLocaleDateString()}</p>
        </div>
        <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadgeClasses(metric.status)}`}>
          {metric.status.charAt(0).toUpperCase() + metric.status.slice(1)}
        </div>
      </div>
      
      <div className="flex items-baseline mt-4 mb-6">
        <div className="text-3xl font-bold text-gray-800">
          {metric.value}
          <span className="text-base ml-1">{metric.unit}</span>
        </div>
        <div className={`ml-4 flex items-center text-sm ${getTrendClasses(isTrendPositive)}`}>
          {trend === 'up' && <TrendingUp className="w-4 h-4 mr-1" />}
          {trend === 'down' && <TrendingDown className="w-4 h-4 mr-1" />}
          {trend === 'stable' && <Minus className="w-4 h-4 mr-1" />}
          {trend !== 'stable' && 
            `${Math.abs((currentValue - previousValue) / previousValue * 100).toFixed(1)}%`
          }
          {trend === 'stable' && 'No change'}
        </div>
      </div>
      
      <div className="h-32">
        <Line data={chartData} options={chartOptions} />
      </div>
      
      <div className="mt-3 text-xs text-gray-500">
        Normal range: {metric.normalRange.min} - {metric.normalRange.max} {metric.unit}
      </div>
    </div>
  );
};

// Helper functions for styling
function getStatusColor(status: 'normal' | 'warning' | 'critical', shade: number): string {
  if (status === 'normal') return `rgb(34, 197, 94, ${shade / 1000})`;
  if (status === 'warning') return `rgb(234, 179, 8, ${shade / 1000})`;
  return `rgb(239, 68, 68, ${shade / 1000})`;
}

function getStatusBadgeClasses(status: 'normal' | 'warning' | 'critical'): string {
  if (status === 'normal') return 'bg-success-50 text-success-700';
  if (status === 'warning') return 'bg-warning-50 text-warning-700';
  return 'bg-error-50 text-error-700';
}

function getTrendClasses(isPositive: boolean): string {
  return isPositive ? 'text-success-600' : 'text-error-600';
}

export default HealthMetricCard;