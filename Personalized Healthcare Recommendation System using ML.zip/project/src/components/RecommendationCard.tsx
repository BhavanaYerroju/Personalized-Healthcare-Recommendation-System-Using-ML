import React, { useState } from 'react';
import { Recommendation } from '../types/health';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface RecommendationCardProps {
  recommendation: Recommendation;
}

const RecommendationCard: React.FC<RecommendationCardProps> = ({ recommendation }) => {
  const [expanded, setExpanded] = useState(false);

  const toggleExpanded = () => {
    setExpanded(!expanded);
  };

  const getPriorityClasses = (priority: 'high' | 'medium' | 'low') => {
    switch (priority) {
      case 'high':
        return 'bg-error-50 text-error-700';
      case 'medium':
        return 'bg-warning-50 text-warning-700';
      case 'low':
        return 'bg-success-50 text-success-700';
    }
  };

  const getCategoryIcon = (category: 'diet' | 'exercise' | 'lifestyle' | 'medical' | 'preventive') => {
    switch (category) {
      case 'diet':
        return '🍽️';
      case 'exercise':
        return '🏃‍♂️';
      case 'lifestyle':
        return '🌿';
      case 'medical':
        return '💊';
      case 'preventive':
        return '🛡️';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg">
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center">
            <span className="text-2xl mr-3">{getCategoryIcon(recommendation.category)}</span>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">{recommendation.title}</h3>
              <div className="flex items-center mt-1">
                <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getPriorityClasses(recommendation.priority)}`}>
                  {recommendation.priority.charAt(0).toUpperCase() + recommendation.priority.slice(1)} Priority
                </span>
                <span className="ml-2 text-xs text-gray-500">
                  {Math.round(recommendation.confidence * 100)}% confidence
                </span>
              </div>
            </div>
          </div>
          <button 
            onClick={toggleExpanded}
            className="p-1 rounded-full hover:bg-gray-100 transition-colors"
            aria-label={expanded ? "Collapse" : "Expand"}
          >
            {expanded ? (
              <ChevronUp className="h-5 w-5 text-gray-500" />
            ) : (
              <ChevronDown className="h-5 w-5 text-gray-500" />
            )}
          </button>
        </div>
        
        <p className="mt-3 text-gray-600">
          {recommendation.description}
        </p>
        
        {expanded && (
          <div className="mt-4 animate-fade-in">
            {recommendation.implementationSteps && (
              <div className="mt-3">
                <h4 className="font-medium text-gray-800 mb-2">Implementation Steps:</h4>
                <ul className="list-disc pl-5 space-y-1">
                  {recommendation.implementationSteps.map((step, index) => (
                    <li key={index} className="text-gray-600">{step}</li>
                  ))}
                </ul>
              </div>
            )}
            
            <div className="mt-4 text-sm text-gray-500 border-t pt-3">
              <p>Source: {recommendation.source}</p>
              <p>Recommended on: {new Date(recommendation.dateCreated).toLocaleDateString()}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RecommendationCard;