import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Heart, 
  Activity, 
  User, 
  ListChecks, 
  AlertTriangle, 
  Database,
  Menu,
  X
} from 'lucide-react';
import { useHealthData } from '../context/HealthDataContext';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const { isLoading } = useHealthData();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const navLinks = [
    { path: '/', name: 'Dashboard', icon: <Activity className="w-5 h-5" /> },
    { path: '/profile', name: 'Health Profile', icon: <User className="w-5 h-5" /> },
    { path: '/recommendations', name: 'Recommendations', icon: <ListChecks className="w-5 h-5" /> },
    { path: '/risk-assessment', name: 'Risk Assessment', icon: <AlertTriangle className="w-5 h-5" /> },
    { path: '/dataset-explorer', name: 'Dataset Explorer', icon: <Database className="w-5 h-5" /> },
  ];

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-primary-50">
        <div className="text-center">
          <div className="animate-pulse flex space-x-4 mb-4 justify-center">
            <Heart className="w-12 h-12 text-primary-500" />
          </div>
          <h2 className="text-xl font-semibold text-primary-800">Loading HealthSage AI...</h2>
          <p className="text-primary-600 mt-2">Preparing your personalized health insights</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-primary-600" />
              <h1 className="ml-2 text-2xl font-bold text-gray-900">HealthSage AI</h1>
            </div>
            
            {/* Mobile menu button */}
            <div className="md:hidden">
              <button 
                onClick={toggleMenu}
                className="p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none"
              >
                {isMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 flex flex-col md:flex-row">
        {/* Sidebar for desktop */}
        <aside className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 md:pt-16">
          <div className="flex-1 flex flex-col min-h-0 border-r border-gray-200 bg-white">
            <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
              <nav className="mt-5 flex-1 px-2 space-y-1">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`group flex items-center px-4 py-3 text-sm font-medium rounded-md transition-all ${
                      location.pathname === link.path
                        ? 'bg-primary-50 text-primary-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                  >
                    <span className={`mr-3 ${
                      location.pathname === link.path
                        ? 'text-primary-500'
                        : 'text-gray-400 group-hover:text-gray-500'
                    }`}>
                      {link.icon}
                    </span>
                    {link.name}
                  </Link>
                ))}
              </nav>
            </div>
          </div>
        </aside>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden fixed inset-0 z-40 flex">
            <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={toggleMenu}></div>
            <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white">
              <div className="flex-1 h-0 pt-5 pb-4 overflow-y-auto">
                <nav className="mt-5 px-2 space-y-1">
                  {navLinks.map((link) => (
                    <Link
                      key={link.path}
                      to={link.path}
                      onClick={toggleMenu}
                      className={`group flex items-center px-4 py-3 text-base font-medium rounded-md transition-all ${
                        location.pathname === link.path
                          ? 'bg-primary-50 text-primary-700'
                          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                      }`}
                    >
                      <span className={`mr-3 ${
                        location.pathname === link.path
                          ? 'text-primary-500'
                          : 'text-gray-400 group-hover:text-gray-500'
                      }`}>
                        {link.icon}
                      </span>
                      {link.name}
                    </Link>
                  ))}
                </nav>
              </div>
            </div>
          </div>
        )}

        {/* Main content */}
        <main className="flex-1 md:pl-64 pt-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;