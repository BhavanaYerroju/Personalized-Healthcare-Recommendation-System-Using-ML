import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import HealthProfile from './pages/HealthProfile';
import Recommendations from './pages/Recommendations';
import RiskAssessment from './pages/RiskAssessment';
import DatasetExplorer from './pages/DatasetExplorer';
import { HealthDataProvider } from './context/HealthDataContext';

function App() {
  return (
    <HealthDataProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/profile" element={<HealthProfile />} />
          <Route path="/recommendations" element={<Recommendations />} />
          <Route path="/risk-assessment" element={<RiskAssessment />} />
          <Route path="/dataset-explorer" element={<DatasetExplorer />} />
        </Routes>
      </Layout>
    </HealthDataProvider>
  );
}

export default App;