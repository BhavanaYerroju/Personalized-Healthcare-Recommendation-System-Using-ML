import React, { createContext, useContext, useState, useEffect } from 'react';
import { HealthData, HealthMetric, User } from '../types/health';
import { initialHealthData } from '../data/initialData';

interface HealthDataContextType {
  healthData: HealthData;
  updateHealthData: (data: Partial<HealthData>) => void;
  updateMetric: (metric: HealthMetric) => void;
  isLoading: boolean;
  currentUser: User;
  setCurrentUser: (user: User) => void;
  availableUsers: User[];
}

const HealthDataContext = createContext<HealthDataContextType | undefined>(undefined);

export const useHealthData = () => {
  const context = useContext(HealthDataContext);
  if (context === undefined) {
    throw new Error('useHealthData must be used within a HealthDataProvider');
  }
  return context;
};

const mockUsers: User[] = [
  {
    id: 'user-1',
    name: 'Jane Smith',
    email: 'jane.smith@example.com',
    healthData: initialHealthData
  },
  {
    id: 'user-2',
    name: 'John Doe',
    email: 'john.doe@example.com',
    healthData: {
      ...initialHealthData,
      userId: 'user-2',
      profile: {
        ...initialHealthData.profile,
        age: 35,
        gender: 'male',
        height: 180,
        weight: 85,
        medicalConditions: ['Type 2 Diabetes'],
        medications: ['Metformin 500mg'],
      }
    }
  }
];

interface HealthDataProviderProps {
  children: React.ReactNode;
}

export const HealthDataProvider: React.FC<HealthDataProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User>(mockUsers[0]);
  const [healthData, setHealthData] = useState<HealthData>(currentUser.healthData);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    setHealthData(currentUser.healthData);
  }, [currentUser]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const updateHealthData = (data: Partial<HealthData>) => {
    setHealthData(prevData => ({
      ...prevData,
      ...data,
    }));
  };

  const updateMetric = (metric: HealthMetric) => {
    setHealthData(prevData => ({
      ...prevData,
      metrics: prevData.metrics.map(m => 
        m.id === metric.id ? metric : m
      ),
    }));
  };

  return (
    <HealthDataContext.Provider value={{ 
      healthData, 
      updateHealthData, 
      updateMetric, 
      isLoading,
      currentUser,
      setCurrentUser,
      availableUsers: mockUsers
    }}>
      {children}
    </HealthDataContext.Provider>
  );
};