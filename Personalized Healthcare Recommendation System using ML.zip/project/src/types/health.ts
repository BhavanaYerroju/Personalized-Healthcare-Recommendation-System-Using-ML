export interface HealthData {
  userId: string;
  profile: UserProfile;
  metrics: HealthMetric[];
  recommendations: Recommendation[];
  riskFactors: RiskFactor[];
  history: HealthHistoryEntry[];
}

export interface UserProfile {
  age: number;
  gender: string;
  height: number; // in cm
  weight: number; // in kg
  medicalConditions: string[];
  medications: string[];
  familyHistory: string[];
  lifestyle: {
    smokingStatus: 'never' | 'former' | 'current';
    alcoholConsumption: 'none' | 'light' | 'moderate' | 'heavy';
    exerciseFrequency: 'none' | 'light' | 'moderate' | 'active' | 'very active';
    diet: 'poor' | 'fair' | 'good' | 'excellent';
    sleepHours: number;
    stressLevel: 'low' | 'moderate' | 'high';
  };
}

export interface HealthMetric {
  id: string;
  name: string;
  value: number;
  unit: string;
  date: Date;
  status: 'normal' | 'warning' | 'critical';
  normalRange: {
    min: number;
    max: number;
  };
  history: {
    value: number;
    date: Date;
  }[];
}

export interface Recommendation {
  id: string;
  category: 'diet' | 'exercise' | 'lifestyle' | 'medical' | 'preventive';
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  source: string;
  confidence: number; // 0-1
  dateCreated: Date;
  implementationSteps?: string[];
}

export interface RiskFactor {
  id: string;
  condition: string;
  riskLevel: 'low' | 'moderate' | 'high';
  probability: number; // 0-1
  contributingFactors: string[];
  preventiveActions: string[];
  description: string;
}

export interface HealthHistoryEntry {
  date: Date;
  metrics: {
    metricId: string;
    value: number;
  }[];
  notes?: string;
}

export interface Dataset {
  id: string;
  name: string;
  description: string;
  source: string;
  size: number;
  features: string[];
  dateAccessed: Date;
  url: string;
}

export interface ModelResult {
  modelId: string;
  modelName: string;
  predictionDate: Date;
  confidence: number;
  results: Record<string, any>;
  interpretations: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  healthData: HealthData;
}