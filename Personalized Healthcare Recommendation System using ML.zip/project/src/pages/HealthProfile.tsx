import React, { useState } from 'react';
import { useHealthData } from '../context/HealthDataContext';
import HealthMetricCard from '../components/HealthMetricCard';
import { Edit2, Save, User, Activity, Heart, Pill, Users, CalendarClock } from 'lucide-react';

const HealthProfile: React.FC = () => {
  const { healthData, updateHealthData } = useHealthData();
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({ ...healthData.profile });
  
  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setProfileData({
        ...profileData,
        [parent]: {
          ...profileData[parent as keyof typeof profileData],
          [child]: value,
        },
      });
    } else {
      setProfileData({
        ...profileData,
        [name]: value,
      });
    }
  };
  
  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setProfileData({
        ...profileData,
        [parent]: {
          ...profileData[parent as keyof typeof profileData],
          [child]: parseFloat(value),
        },
      });
    } else {
      setProfileData({
        ...profileData,
        [name]: parseFloat(value),
      });
    }
  };
  
  const toggleEditing = () => {
    setIsEditing(!isEditing);
    if (isEditing) {
      updateHealthData({ profile: profileData });
    }
  };

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Health Profile</h1>
        <button
          onClick={toggleEditing}
          className={`px-4 py-2 rounded-md flex items-center text-sm font-medium ${
            isEditing ? 'bg-success-500 hover:bg-success-600 text-white' : 'bg-primary-500 hover:bg-primary-600 text-white'
          }`}
        >
          {isEditing ? (
            <>
              <Save className="w-4 h-4 mr-2" /> Save Profile
            </>
          ) : (
            <>
              <Edit2 className="w-4 h-4 mr-2" /> Edit Profile
            </>
          )}
        </button>
      </div>
      
      {/* Profile Information */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <User className="w-5 h-5 mr-2" /> Personal Information
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Age</label>
            {isEditing ? (
              <input
                type="number"
                name="age"
                value={profileData.age}
                onChange={handleNumberChange}
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              />
            ) : (
              <p className="text-gray-900">{profileData.age} years</p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
            {isEditing ? (
              <select
                name="gender"
                value={profileData.gender}
                onChange={handleProfileChange}
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            ) : (
              <p className="text-gray-900">{profileData.gender.charAt(0).toUpperCase() + profileData.gender.slice(1)}</p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Height</label>
            {isEditing ? (
              <input
                type="number"
                name="height"
                value={profileData.height}
                onChange={handleNumberChange}
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              />
            ) : (
              <p className="text-gray-900">{profileData.height} cm</p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Weight</label>
            {isEditing ? (
              <input
                type="number"
                name="weight"
                value={profileData.weight}
                onChange={handleNumberChange}
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              />
            ) : (
              <p className="text-gray-900">{profileData.weight} kg</p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">BMI</label>
            <p className="text-gray-900">
              {(profileData.weight / ((profileData.height / 100) * (profileData.height / 100))).toFixed(1)} kg/m²
            </p>
          </div>
        </div>
      </div>
      
      {/* Lifestyle Information */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <Activity className="w-5 h-5 mr-2" /> Lifestyle Information
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Smoking Status</label>
            {isEditing ? (
              <select
                name="lifestyle.smokingStatus"
                value={profileData.lifestyle.smokingStatus}
                onChange={handleProfileChange}
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              >
                <option value="never">Never Smoked</option>
                <option value="former">Former Smoker</option>
                <option value="current">Current Smoker</option>
              </select>
            ) : (
              <p className="text-gray-900">
                {profileData.lifestyle.smokingStatus === 'never' && 'Never Smoked'}
                {profileData.lifestyle.smokingStatus === 'former' && 'Former Smoker'}
                {profileData.lifestyle.smokingStatus === 'current' && 'Current Smoker'}
              </p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Alcohol Consumption</label>
            {isEditing ? (
              <select
                name="lifestyle.alcoholConsumption"
                value={profileData.lifestyle.alcoholConsumption}
                onChange={handleProfileChange}
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              >
                <option value="none">None</option>
                <option value="light">Light</option>
                <option value="moderate">Moderate</option>
                <option value="heavy">Heavy</option>
              </select>
            ) : (
              <p className="text-gray-900">
                {profileData.lifestyle.alcoholConsumption.charAt(0).toUpperCase() + profileData.lifestyle.alcoholConsumption.slice(1)}
              </p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Exercise Frequency</label>
            {isEditing ? (
              <select
                name="lifestyle.exerciseFrequency"
                value={profileData.lifestyle.exerciseFrequency}
                onChange={handleProfileChange}
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              >
                <option value="none">None</option>
                <option value="light">Light</option>
                <option value="moderate">Moderate</option>
                <option value="active">Active</option>
                <option value="very active">Very Active</option>
              </select>
            ) : (
              <p className="text-gray-900">
                {profileData.lifestyle.exerciseFrequency.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
              </p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Diet Quality</label>
            {isEditing ? (
              <select
                name="lifestyle.diet"
                value={profileData.lifestyle.diet}
                onChange={handleProfileChange}
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              >
                <option value="poor">Poor</option>
                <option value="fair">Fair</option>
                <option value="good">Good</option>
                <option value="excellent">Excellent</option>
              </select>
            ) : (
              <p className="text-gray-900">
                {profileData.lifestyle.diet.charAt(0).toUpperCase() + profileData.lifestyle.diet.slice(1)}
              </p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Sleep Hours</label>
            {isEditing ? (
              <input
                type="number"
                name="lifestyle.sleepHours"
                value={profileData.lifestyle.sleepHours}
                onChange={handleNumberChange}
                step="0.5"
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              />
            ) : (
              <p className="text-gray-900">{profileData.lifestyle.sleepHours} hours</p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Stress Level</label>
            {isEditing ? (
              <select
                name="lifestyle.stressLevel"
                value={profileData.lifestyle.stressLevel}
                onChange={handleProfileChange}
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              >
                <option value="low">Low</option>
                <option value="moderate">Moderate</option>
                <option value="high">High</option>
              </select>
            ) : (
              <p className="text-gray-900">
                {profileData.lifestyle.stressLevel.charAt(0).toUpperCase() + profileData.lifestyle.stressLevel.slice(1)}
              </p>
            )}
          </div>
        </div>
      </div>
      
      {/* Medical Information */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <Heart className="w-5 h-5 mr-2" /> Medical Conditions
        </h2>
        
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {healthData.profile.medicalConditions.map((condition, index) => (
              <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                {condition}
              </span>
            ))}
          </div>
        </div>
        
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <Pill className="w-5 h-5 mr-2" /> Medications
        </h2>
        
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {healthData.profile.medications.map((medication, index) => (
              <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800">
                {medication}
              </span>
            ))}
          </div>
        </div>
        
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <Users className="w-5 h-5 mr-2" /> Family History
        </h2>
        
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {healthData.profile.familyHistory.map((condition, index) => (
              <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent-100 text-accent-800">
                {condition}
              </span>
            ))}
          </div>
        </div>
      </div>
      
      {/* Health Metrics */}
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <CalendarClock className="w-5 h-5 mr-2" /> Health Metrics
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {healthData.metrics.map(metric => (
            <HealthMetricCard key={metric.id} metric={metric} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default HealthProfile;