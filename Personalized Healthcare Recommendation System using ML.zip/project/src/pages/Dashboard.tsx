import React from 'react';
import { useHealthData } from '../context/HealthDataContext';
import HealthMetricCard from '../components/HealthMetricCard';
import RecommendationCard from '../components/RecommendationCard';
import { ChevronRight, AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const { healthData } = useHealthData();
  
  // Get top metrics to display
  const topMetrics = healthData.metrics.slice(0, 4);
  
  // Get high priority recommendations
  const highPriorityRecommendations = healthData.recommendations
    .filter(rec => rec.priority === 'high')
    .slice(0, 3);
  
  // Get high risk factors
  const highRiskFactors = healthData.riskFactors
    .filter(risk => risk.riskLevel === 'high' || risk.riskLevel === 'moderate')
    .slice(0, 2);

  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Health Dashboard</h1>
      
      {/* Welcome section */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold mb-2">Welcome to your health dashboard</h2>
        <p className="text-gray-600">
          Here's a summary of your health status and personalized recommendations based on your data.
        </p>
        
        {/* Quick stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          <div className="bg-primary-50 rounded-lg p-4">
            <p className="text-sm text-primary-700">BMI</p>
            <p className="text-2xl font-bold text-primary-900">
              {healthData.metrics.find(m => m.id === 'bmi')?.value || '-'}
            </p>
          </div>
          <div className="bg-secondary-50 rounded-lg p-4">
            <p className="text-sm text-secondary-700">Blood Pressure</p>
            <p className="text-2xl font-bold text-secondary-900">
              {healthData.metrics.find(m => m.id === 'bp-systolic')?.value || '-'}/
              {healthData.metrics.find(m => m.id === 'bp-diastolic')?.value || '-'}
            </p>
          </div>
          <div className="bg-accent-50 rounded-lg p-4">
            <p className="text-sm text-accent-700">Total Cholesterol</p>
            <p className="text-2xl font-bold text-accent-900">
              {healthData.metrics.find(m => m.id === 'cholesterol-total')?.value || '-'} mg/dL
            </p>
          </div>
          <div className="bg-success-50 rounded-lg p-4">
            <p className="text-sm text-success-700">Glucose</p>
            <p className="text-2xl font-bold text-success-900">
              {healthData.metrics.find(m => m.id === 'glucose')?.value || '-'} mg/dL
            </p>
          </div>
        </div>
      </div>
      
      {/* Health metrics section */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Key Health Metrics</h2>
          <Link to="/profile" className="text-primary-600 hover:text-primary-800 flex items-center text-sm font-medium">
            View all metrics <ChevronRight className="w-4 h-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {topMetrics.map(metric => (
            <HealthMetricCard key={metric.id} metric={metric} />
          ))}
        </div>
      </div>
      
      {/* Recommendations section */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Top Recommendations</h2>
          <Link to="/recommendations" className="text-primary-600 hover:text-primary-800 flex items-center text-sm font-medium">
            View all recommendations <ChevronRight className="w-4 h-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {highPriorityRecommendations.map(recommendation => (
            <RecommendationCard key={recommendation.id} recommendation={recommendation} />
          ))}
        </div>
      </div>
      
      {/* Risk factors section */}
      {highRiskFactors.length > 0 && (
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <h2 className="text-xl font-semibold text-gray-900">Health Risk Alerts</h2>
              <AlertTriangle className="w-5 h-5 ml-2 text-warning-500" />
            </div>
            <Link to="/risk-assessment" className="text-primary-600 hover:text-primary-800 flex items-center text-sm font-medium">
              View risk assessment <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="bg-warning-50 border border-warning-200 rounded-lg p-4 mb-4">
            <p className="text-warning-800">
              Our analysis has identified some potential health risks you should be aware of. Review the details below and consider discussing them with your healthcare provider.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {highRiskFactors.map(risk => (
              <div key={risk.id} className="bg-white rounded-lg shadow-md p-4">
                <div className="flex items-start">
                  <AlertTriangle className="w-5 h-5 text-warning-500 mt-1 mr-2 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-gray-800">{risk.condition}</h3>
                    <p className="text-gray-600 mt-1">{risk.description}</p>
                    <Link 
                      to="/risk-assessment" 
                      className="text-primary-600 hover:text-primary-800 text-sm font-medium inline-block mt-2"
                    >
                      Learn more
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Recent activity section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <ul className="divide-y divide-gray-200">
            {healthData.history.slice(0, 3).map((entry, index) => (
              <li key={index} className="p-4 hover:bg-gray-50">
                <div className="flex justify-between">
                  <div>
                    <p className="font-medium text-gray-800">
                      Health check on {new Date(entry.date).toLocaleDateString()}
                    </p>
                    <p className="text-sm text-gray-500 mt-1">{entry.notes}</p>
                  </div>
                  <span className="text-xs text-gray-400">
                    {new Date(entry.date).toLocaleDateString()}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;