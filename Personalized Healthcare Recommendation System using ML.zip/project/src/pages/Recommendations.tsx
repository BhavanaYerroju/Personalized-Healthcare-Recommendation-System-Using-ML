import React, { useState } from 'react';
import { useHealthData } from '../context/HealthDataContext';
import RecommendationCard from '../components/RecommendationCard';
import { Filter, Users } from 'lucide-react';

const Recommendations: React.FC = () => {
  const { healthData, currentUser, setCurrentUser, availableUsers } = useHealthData();
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  
  const filteredRecommendations = healthData.recommendations.filter(rec => {
    const matchesCategory = categoryFilter === 'all' || rec.category === categoryFilter;
    const matchesPriority = priorityFilter === 'all' || rec.priority === priorityFilter;
    return matchesCategory && matchesPriority;
  });
  
  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'diet', label: 'Diet' },
    { value: 'exercise', label: 'Exercise' },
    { value: 'lifestyle', label: 'Lifestyle' },
    { value: 'medical', label: 'Medical' },
    { value: 'preventive', label: 'Preventive' },
  ];
  
  const priorities = [
    { value: 'all', label: 'All Priorities' },
    { value: 'high', label: 'High' },
    { value: 'medium', label: 'Medium' },
    { value: 'low', label: 'Low' },
  ];

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Personalized Health Recommendations</h1>
        <div className="flex items-center space-x-2">
          <Users className="w-5 h-5 text-gray-500" />
          <select
            className="block w-48 border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
            value={currentUser.id}
            onChange={(e) => {
              const selectedUser = availableUsers.find(user => user.id === e.target.value);
              if (selectedUser) setCurrentUser(selectedUser);
            }}
          >
            {availableUsers.map(user => (
              <option key={user.id} value={user.id}>
                {user.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      {/* Introduction */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">About Your Recommendations</h2>
        <p className="text-gray-600">
          These recommendations are generated based on {currentUser.name}'s health profile, medical history, and current health metrics. 
          They are personalized to address specific health needs and risk factors.
        </p>
        <p className="text-gray-600 mt-2">
          Our machine learning model analyzes patterns from thousands of similar health profiles to provide 
          evidence-based suggestions that have shown positive outcomes for people with similar health characteristics.
        </p>
        <div className="mt-4 p-4 bg-primary-50 rounded-md">
          <p className="text-primary-800 font-medium">
            Always consult with your healthcare provider before making significant changes to your health regimen.
          </p>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex items-center mb-4">
          <Filter className="w-5 h-5 text-gray-500 mr-2" />
          <h2 className="text-lg font-medium text-gray-900">Filter Recommendations</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="category-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Category
            </label>
            <select
              id="category-filter"
              className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
            >
              {categories.map((category) => (
                <option key={category.value} value={category.value}>
                  {category.label}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="priority-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Priority
            </label>
            <select
              id="priority-filter"
              className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
            >
              {priorities.map((priority) => (
                <option key={priority.value} value={priority.value}>
                  {priority.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      
      {/* Recommendations */}
      <div className="grid grid-cols-1 gap-4">
        {filteredRecommendations.length > 0 ? (
          filteredRecommendations.map(recommendation => (
            <RecommendationCard key={recommendation.id} recommendation={recommendation} />
          ))
        ) : (
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <p className="text-gray-600">No recommendations match your current filters.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Recommendations;