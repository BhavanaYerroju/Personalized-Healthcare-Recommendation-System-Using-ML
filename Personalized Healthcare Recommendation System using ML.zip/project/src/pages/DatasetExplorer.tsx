import React, { useState } from 'react';
import { datasets } from '../data/initialData';
import { Database, ExternalLink, Search, Filter, Download } from 'lucide-react';

const DatasetExplorer: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDataset, setSelectedDataset] = useState<string | null>(null);
  
  // Filter datasets based on search term
  const filteredDatasets = datasets.filter(dataset => 
    dataset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dataset.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dataset.features.some(feature => feature.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  
  // Get the selected dataset details
  const datasetDetails = selectedDataset 
    ? datasets.find(d => d.id === selectedDataset) 
    : null;
  
  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Health Dataset Explorer</h1>
      
      {/* Introduction */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2 flex items-center">
          <Database className="w-5 h-5 mr-2" /> About the Datasets
        </h2>
        <p className="text-gray-600">
          Our healthcare recommendation system is trained on high-quality, real-world healthcare datasets.
          These datasets contain anonymized patient information that helps our machine learning models identify 
          patterns and make personalized health recommendations.
        </p>
        <p className="text-gray-600 mt-2">
          Explore the datasets below to understand the data that powers your personalized health insights.
        </p>
      </div>
      
      {/* Search and Filter */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex items-center mb-4">
          <Search className="w-5 h-5 text-gray-500 mr-2" />
          <h2 className="text-lg font-medium text-gray-900">Search Datasets</h2>
        </div>
        
        <div className="relative">
          <input
            type="text"
            placeholder="Search by dataset name, description, or features..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
        </div>
      </div>
      
      {/* Dataset List and Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Dataset List */}
        <div className="lg:col-span-1">
          <h2 className="text-lg font-medium text-gray-900 mb-3">Available Datasets</h2>
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <ul className="divide-y divide-gray-200">
              {filteredDatasets.length > 0 ? (
                filteredDatasets.map((dataset) => (
                  <li 
                    key={dataset.id}
                    className={`hover:bg-gray-50 cursor-pointer ${selectedDataset === dataset.id ? 'bg-primary-50' : ''}`}
                    onClick={() => setSelectedDataset(dataset.id)}
                  >
                    <div className="px-4 py-4">
                      <div className="flex justify-between">
                        <h3 className="text-sm font-medium text-gray-900">{dataset.name}</h3>
                        <span className="text-xs text-gray-500">{dataset.size.toLocaleString()} records</span>
                      </div>
                      <p className="mt-1 text-xs text-gray-500 line-clamp-2">{dataset.description}</p>
                    </div>
                  </li>
                ))
              ) : (
                <li className="px-4 py-4 text-center text-gray-500">
                  No datasets match your search criteria
                </li>
              )}
            </ul>
          </div>
        </div>
        
        {/* Dataset Details */}
        <div className="lg:col-span-2">
          <h2 className="text-lg font-medium text-gray-900 mb-3">Dataset Details</h2>
          {datasetDetails ? (
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-semibold text-gray-900">{datasetDetails.name}</h3>
                <div className="flex space-x-2">
                  <a 
                    href={datasetDetails.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                  >
                    <ExternalLink className="w-4 h-4 mr-1" />
                    View Source
                  </a>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <p className="text-sm font-medium text-gray-500">Source</p>
                  <p className="mt-1 text-sm text-gray-900">{datasetDetails.source}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Size</p>
                  <p className="mt-1 text-sm text-gray-900">{datasetDetails.size.toLocaleString()} records</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Last Accessed</p>
                  <p className="mt-1 text-sm text-gray-900">{new Date(datasetDetails.dateAccessed).toLocaleDateString()}</p>
                </div>
              </div>
              
              <div className="mb-6">
                <p className="text-sm font-medium text-gray-500 mb-2">Description</p>
                <p className="text-sm text-gray-900">{datasetDetails.description}</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500 mb-2">Features</p>
                <div className="flex flex-wrap gap-2">
                  {datasetDetails.features.map((feature, index) => (
                    <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="mt-6 pt-4 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-900 mb-2">How This Dataset Powers Your Recommendations</h4>
                <p className="text-sm text-gray-600">
                  This dataset is analyzed by our machine learning models to identify patterns between health factors and outcomes. 
                  Your personal health data is compared against these patterns to generate recommendations tailored specifically to you.
                </p>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <Database className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Select a dataset to view details</h3>
              <p className="text-gray-500">
                Click on any dataset from the list to view more information about it.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DatasetExplorer;