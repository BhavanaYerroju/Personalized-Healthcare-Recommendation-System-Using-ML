import React from 'react';
import { useHealthData } from '../context/HealthDataContext';
import RiskFactorCard from '../components/RiskFactorCard';
import { AlertTriangle, TrendingDown, Info } from 'lucide-react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend);

const RiskAssessment: React.FC = () => {
  const { healthData } = useHealthData();
  
  // Calculate overall risk score (simplified version)
  const calculateOverallRisk = () => {
    const riskWeights = { low: 1, moderate: 2, high: 3 };
    const totalWeight = healthData.riskFactors.reduce(
      (sum, risk) => sum + riskWeights[risk.riskLevel as keyof typeof riskWeights], 
      0
    );
    return Math.min(totalWeight / (healthData.riskFactors.length * 3), 1);
  };
  
  const overallRisk = calculateOverallRisk();
  
  // Data for the risk doughnut chart
  const riskChartData = {
    labels: ['Risk Score', 'Remaining'],
    datasets: [
      {
        data: [overallRisk * 100, 100 - (overallRisk * 100)],
        backgroundColor: [
          overallRisk < 0.3 ? 'rgb(34, 197, 94)' : overallRisk < 0.6 ? 'rgb(234, 179, 8)' : 'rgb(239, 68, 68)',
          'rgb(229, 231, 235)',
        ],
        borderWidth: 0,
      },
    ],
  };
  
  const riskChartOptions = {
    responsive: true,
    cutout: '75%',
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        enabled: false,
      },
    },
    maintainAspectRatio: false,
  };
  
  // Get risk levels counts
  const riskLevelCounts = healthData.riskFactors.reduce(
    (counts, risk) => {
      counts[risk.riskLevel]++;
      return counts;
    },
    { low: 0, moderate: 0, high: 0 } as Record<string, number>
  );
  
  // Helper function to get risk level text
  const getRiskLevelText = (risk: number) => {
    if (risk < 0.3) return { text: 'Low', color: 'text-success-700' };
    if (risk < 0.6) return { text: 'Moderate', color: 'text-warning-700' };
    return { text: 'High', color: 'text-error-700' };
  };
  
  const riskLevel = getRiskLevelText(overallRisk);

  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Health Risk Assessment</h1>
      
      {/* Introduction */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2 flex items-center">
          <Info className="w-5 h-5 mr-2" /> About Your Risk Assessment
        </h2>
        <p className="text-gray-600">
          This risk assessment is based on your health profile, family history, lifestyle factors, and current health metrics.
          It identifies potential health conditions you may be at risk for and provides information on how to reduce these risks.
        </p>
        <div className="mt-4 p-4 bg-primary-50 rounded-md">
          <p className="text-primary-800 font-medium">
            This assessment is for informational purposes only and should not replace professional medical advice.
            Always consult with your healthcare provider about your specific health risks.
          </p>
        </div>
      </div>
      
      {/* Overall Risk Score */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Overall Health Risk</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex justify-center items-center">
            <div className="relative h-48 w-48">
              <Doughnut data={riskChartData} options={riskChartOptions} />
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold text-gray-900">{Math.round(overallRisk * 100)}%</span>
                <span className={`text-lg font-medium ${riskLevel.color}`}>{riskLevel.text}</span>
              </div>
            </div>
          </div>
          
          <div className="md:col-span-2">
            <h3 className="font-medium text-lg text-gray-900 mb-2">Risk Summary</h3>
            <p className="text-gray-600 mb-4">
              Based on your health profile and current metrics, your overall health risk is 
              <span className={`font-medium ${riskLevel.color}`}> {riskLevel.text.toLowerCase()}</span>.
            </p>
            
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="bg-success-50 rounded-lg p-3 text-center">
                <p className="text-success-700 font-medium">Low Risk</p>
                <p className="text-2xl font-bold text-success-800">{riskLevelCounts.low}</p>
              </div>
              <div className="bg-warning-50 rounded-lg p-3 text-center">
                <p className="text-warning-700 font-medium">Moderate</p>
                <p className="text-2xl font-bold text-warning-800">{riskLevelCounts.moderate}</p>
              </div>
              <div className="bg-error-50 rounded-lg p-3 text-center">
                <p className="text-error-700 font-medium">High Risk</p>
                <p className="text-2xl font-bold text-error-800">{riskLevelCounts.high}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <TrendingDown className="w-5 h-5 text-primary-600 mt-1 mr-2 flex-shrink-0" />
              <p className="text-gray-600">
                Following the personalized recommendations provided in this assessment can help lower your risk factors and improve your overall health.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Specific Risk Factors */}
      <div className="mb-6">
        <div className="flex items-center mb-4">
          <AlertTriangle className="w-5 h-5 text-warning-500 mr-2" />
          <h2 className="text-xl font-semibold text-gray-900">Identified Risk Factors</h2>
        </div>
        
        <div className="space-y-4">
          {healthData.riskFactors.map(riskFactor => (
            <RiskFactorCard key={riskFactor.id} riskFactor={riskFactor} />
          ))}
        </div>
      </div>
      
      {/* Prevention Tips */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">General Prevention Tips</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="font-medium text-lg text-gray-900 mb-2">Lifestyle Modifications</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <span className="text-gray-600">Regular physical activity (150+ minutes per week)</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <span className="text-gray-600">Balanced diet rich in fruits, vegetables, and whole grains</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <span className="text-gray-600">Maintain a healthy weight (BMI between 18.5-24.9)</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <span className="text-gray-600">Limit alcohol consumption</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <span className="text-gray-600">Avoid tobacco use</span>
              </li>
            </ul>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="font-medium text-lg text-gray-900 mb-2">Preventive Healthcare</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <span className="text-gray-600">Regular check-ups with your healthcare provider</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <span className="text-gray-600">Age-appropriate screenings and vaccinations</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <span className="text-gray-600">Regular monitoring of blood pressure, cholesterol, and glucose</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <span className="text-gray-600">Medication adherence for existing conditions</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary-600 mr-2">•</span>
                <span className="text-gray-600">Stress management techniques</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RiskAssessment;